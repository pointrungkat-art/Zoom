import { createFileRoute } from "@tanstack/react-router";
import { StillApp } from "@/components/still-app";

export const Route = createFileRoute("/")({ component: StillApp });
