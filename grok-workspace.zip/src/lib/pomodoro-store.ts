import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  clampSettings,
  completePhase,
  DEFAULT_SETTINGS,
  durationMs,
  sanitizeTasks,
  todayKey,
  type Phase,
  type Settings,
  type Task,
} from "./pomodoro-logic";

export type RunState = "idle" | "running" | "paused";

type PomodoroState = {
  phase: Phase;
  runState: RunState;
  endsAt: number | null;
  remainingMs: number;
  durationMs: number;
  completedToday: number;
  cycleCount: number;
  dayKey: string;
  tasks: Task[];
  activeTaskId: string | null;
  settings: Settings;
  completion: number;
  lastEvent: Phase | null;
  toggle: () => void;
  reset: () => void;
  finishInterval: () => void;
  selectPhase: (phase: Phase) => void;
  tick: (now: number) => void;
  setFocusMin: (value: number) => void;
  setShortMin: (value: number) => void;
  setLongMin: (value: number) => void;
  setCycles: (value: number) => void;
  applyPreset: (focusMin: number, shortMin: number) => void;
  setSound: (on: boolean) => void;
  addTask: (title: string) => void;
  toggleTask: (id: string) => void;
  removeTask: (id: string) => void;
  setActiveTask: (id: string) => void;
  clearFinished: () => void;
  resetCounts: () => void;
  reconcile: () => void;
};

const INITIAL_DURATION = durationMs("focus", DEFAULT_SETTINGS);

function applySettings(state: PomodoroState, settings: Settings): Partial<PomodoroState> {
  const patch: Partial<PomodoroState> = { settings };
  if (state.cycleCount > settings.cyclesBeforeLong) {
    patch.cycleCount = settings.cyclesBeforeLong;
  }
  const nextDuration = durationMs(state.phase, settings);
  const previousDuration = durationMs(state.phase, state.settings);
  if (state.runState !== "running" && nextDuration !== previousDuration) {
    patch.durationMs = nextDuration;
    patch.remainingMs = nextDuration;
    patch.endsAt = null;
  }
  return patch;
}

function memoryStorage(): Storage {
  const bag = new Map<string, string>();
  return {
    get length() {
      return bag.size;
    },
    clear: () => bag.clear(),
    getItem: (key) => bag.get(key) ?? null,
    key: (index) => [...bag.keys()][index] ?? null,
    removeItem: (key) => {
      bag.delete(key);
    },
    setItem: (key, value) => {
      bag.set(key, value);
    },
  };
}

export const usePomodoro = create<PomodoroState>()(
  persist(
    (set, get) => ({
      phase: "focus",
      runState: "idle",
      endsAt: null,
      remainingMs: INITIAL_DURATION,
      durationMs: INITIAL_DURATION,
      completedToday: 0,
      cycleCount: 0,
      dayKey: "",
      tasks: [],
      activeTaskId: null,
      settings: DEFAULT_SETTINGS,
      completion: 0,
      lastEvent: null,

      toggle: () => {
        const state = get();
        if (state.runState === "running") {
          const left = Math.max(0, (state.endsAt ?? Date.now()) - Date.now());
          set({ runState: "paused", endsAt: null, remainingMs: left });
          return;
        }
        if (state.remainingMs <= 0) {
          get().finishInterval();
          return;
        }
        set({
          runState: "running",
          endsAt: Date.now() + state.remainingMs,
          lastEvent: null,
        });
      },

      reset: () => {
        const state = get();
        const duration = durationMs(state.phase, state.settings);
        set({
          runState: "idle",
          endsAt: null,
          remainingMs: duration,
          durationMs: duration,
          lastEvent: null,
        });
      },

      finishInterval: () => {
        const state = get();
        if (state.runState === "idle") return;
        const result = completePhase({
          phase: state.phase,
          cycleCount: state.cycleCount,
          completedToday: state.completedToday,
          cyclesBeforeLong: state.settings.cyclesBeforeLong,
        });
        const duration = durationMs(result.phase, state.settings);
        const tasks =
          result.countedFocus && state.activeTaskId
            ? state.tasks.map((task) =>
                task.id === state.activeTaskId ? { ...task, pomodoros: task.pomodoros + 1 } : task,
              )
            : state.tasks;
        set({
          phase: result.phase,
          cycleCount: result.cycleCount,
          completedToday: result.completedToday,
          tasks,
          runState: "idle",
          endsAt: null,
          remainingMs: duration,
          durationMs: duration,
          completion: state.completion + 1,
          lastEvent: state.phase,
        });
      },

      selectPhase: (phase) => {
        const state = get();
        if (phase === state.phase || state.runState === "running") return;
        const duration = durationMs(phase, state.settings);
        set({
          phase,
          runState: "idle",
          endsAt: null,
          remainingMs: duration,
          durationMs: duration,
          lastEvent: null,
        });
      },

      tick: (now) => {
        const state = get();
        const key = todayKey();
        if (state.dayKey !== key) {
          set({ dayKey: key, completedToday: 0, cycleCount: 0 });
        }
        const current = get();
        if (current.runState !== "running" || current.endsAt == null) return;
        const left = current.endsAt - now;
        if (left <= 0) {
          get().finishInterval();
          return;
        }
        if (Math.abs(left - current.remainingMs) > 40) {
          set({ remainingMs: left });
        }
      },

      setFocusMin: (value) => {
        const state = get();
        set(applySettings(state, clampSettings({ ...state.settings, focusMin: value })));
      },
      setShortMin: (value) => {
        const state = get();
        set(applySettings(state, clampSettings({ ...state.settings, shortMin: value })));
      },
      setLongMin: (value) => {
        const state = get();
        set(applySettings(state, clampSettings({ ...state.settings, longMin: value })));
      },
      setCycles: (value) => {
        const state = get();
        set(applySettings(state, clampSettings({ ...state.settings, cyclesBeforeLong: value })));
      },
      applyPreset: (focusMin, shortMin) => {
        const state = get();
        set(applySettings(state, clampSettings({ ...state.settings, focusMin, shortMin })));
      },
      setSound: (on) => {
        const state = get();
        set({ settings: { ...state.settings, sound: on } });
      },

      addTask: (title) => {
        const trimmed = title.trim().slice(0, 120);
        if (!trimmed) return;
        const state = get();
        if (state.tasks.length >= 40) return;
        const task: Task = {
          id: crypto.randomUUID(),
          title: trimmed,
          done: false,
          pomodoros: 0,
        };
        set({
          tasks: [task, ...state.tasks],
          activeTaskId: state.activeTaskId ?? task.id,
        });
      },

      toggleTask: (id) => {
        const state = get();
        const tasks = state.tasks.map((task) => (task.id === id ? { ...task, done: !task.done } : task));
        const toggled = tasks.find((task) => task.id === id);
        let activeTaskId = state.activeTaskId;
        if (toggled?.done && activeTaskId === id) {
          activeTaskId = tasks.find((task) => !task.done)?.id ?? null;
        } else if (toggled && !toggled.done) {
          activeTaskId = id;
        }
        set({ tasks, activeTaskId });
      },

      removeTask: (id) => {
        const state = get();
        const tasks = state.tasks.filter((task) => task.id !== id);
        set({
          tasks,
          activeTaskId: state.activeTaskId === id ? (tasks.find((task) => !task.done)?.id ?? null) : state.activeTaskId,
        });
      },

      setActiveTask: (id) => {
        const state = get();
        if (!state.tasks.some((task) => task.id === id)) return;
        set({ activeTaskId: state.activeTaskId === id ? null : id });
      },

      clearFinished: () => {
        const state = get();
        const tasks = state.tasks.filter((task) => !task.done);
        set({
          tasks,
          activeTaskId: tasks.some((task) => task.id === state.activeTaskId) ? state.activeTaskId : null,
        });
      },

      resetCounts: () => set({ completedToday: 0, cycleCount: 0 }),

      reconcile: () => {
        const state = get();
        const settings = clampSettings(state.settings);
        const key = todayKey();
        const rolled = state.dayKey !== key;
        const tasks = sanitizeTasks(state.tasks);
        const activeTaskId = tasks.some((task) => task.id === state.activeTaskId) ? state.activeTaskId : null;
        let phase = state.phase;
        let cycleCount = Math.min(rolled ? 0 : state.cycleCount, settings.cyclesBeforeLong);
        let completedToday = rolled ? 0 : state.completedToday;
        let runState = state.runState;
        let endsAt = state.endsAt;
        let remainingMs = state.remainingMs;
        let span = state.durationMs > 0 ? state.durationMs : durationMs(phase, settings);
        let lastEvent = state.lastEvent;

        if (runState === "running" && endsAt != null && endsAt <= Date.now()) {
          const finished = phase;
          const result = completePhase({
            phase,
            cycleCount,
            completedToday,
            cyclesBeforeLong: settings.cyclesBeforeLong,
          });
          if (result.countedFocus && activeTaskId) {
            const index = tasks.findIndex((task) => task.id === activeTaskId);
            const current = index >= 0 ? tasks[index] : undefined;
            if (current) tasks[index] = { ...current, pomodoros: current.pomodoros + 1 };
          }
          phase = result.phase;
          cycleCount = result.cycleCount;
          completedToday = result.completedToday;
          span = durationMs(phase, settings);
          remainingMs = span;
          runState = "idle";
          endsAt = null;
          lastEvent = finished;
        } else if (runState === "running" && endsAt != null) {
          remainingMs = Math.max(0, endsAt - Date.now());
        } else {
          remainingMs = Math.min(Math.max(0, remainingMs), span);
        }

        set({
          settings,
          dayKey: key,
          tasks,
          activeTaskId,
          phase,
          cycleCount,
          completedToday,
          runState,
          endsAt,
          remainingMs,
          durationMs: span,
          lastEvent,
        });
      },
    }),
    {
      name: "still-pomodoro",
      skipHydration: true,
      storage: createJSONStorage(() =>
        typeof window === "undefined" ? memoryStorage() : window.localStorage,
      ),
      partialize: (state) => ({
        phase: state.phase,
        runState: state.runState,
        endsAt: state.endsAt,
        remainingMs: state.remainingMs,
        durationMs: state.durationMs,
        completedToday: state.completedToday,
        cycleCount: state.cycleCount,
        dayKey: state.dayKey,
        tasks: state.tasks,
        activeTaskId: state.activeTaskId,
        settings: state.settings,
      }),
      onRehydrateStorage: () => (state) => {
        state?.reconcile();
      },
    },
  ),
);
