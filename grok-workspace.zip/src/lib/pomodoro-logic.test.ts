import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  clampSettings,
  completePhase,
  durationMs,
  formatClock,
  sanitizeTasks,
  DEFAULT_SETTINGS,
} from "./pomodoro-logic.ts";

describe("formatClock", () => {
  it("rounds the countdown up to the next second", () => {
    assert.equal(formatClock(0), "00:00");
    assert.equal(formatClock(1), "00:01");
    assert.equal(formatClock(1000), "00:01");
    assert.equal(formatClock(1001), "00:02");
    assert.equal(formatClock(59_000), "00:59");
    assert.equal(formatClock(60_000), "01:00");
    assert.equal(formatClock(25 * 60_000), "25:00");
  });
});

describe("completePhase", () => {
  it("counts a focus and opens a short break", () => {
    assert.deepEqual(
      completePhase({ phase: "focus", cycleCount: 0, completedToday: 0, cyclesBeforeLong: 4 }),
      { phase: "short", cycleCount: 1, completedToday: 1, countedFocus: true },
    );
  });

  it("opens a long break on the last focus of the cycle", () => {
    assert.deepEqual(
      completePhase({ phase: "focus", cycleCount: 3, completedToday: 3, cyclesBeforeLong: 4 }),
      { phase: "long", cycleCount: 4, completedToday: 4, countedFocus: true },
    );
  });

  it("returns to focus after a break without changing the count", () => {
    assert.deepEqual(
      completePhase({ phase: "short", cycleCount: 2, completedToday: 2, cyclesBeforeLong: 4 }),
      { phase: "focus", cycleCount: 2, completedToday: 2, countedFocus: false },
    );
    assert.deepEqual(
      completePhase({ phase: "long", cycleCount: 4, completedToday: 4, cyclesBeforeLong: 4 }),
      { phase: "focus", cycleCount: 0, completedToday: 4, countedFocus: false },
    );
  });
});

describe("settings and tasks", () => {
  it("clamps lengths and falls back when values are missing", () => {
    assert.deepEqual(clampSettings(undefined), DEFAULT_SETTINGS);
    assert.equal(clampSettings({ focusMin: 0, shortMin: 90, longMin: 12.4, cyclesBeforeLong: 99 }).focusMin, 1);
    assert.equal(clampSettings({ shortMin: 90 }).shortMin, 45);
    assert.equal(clampSettings({ longMin: 12.4 }).longMin, 12);
    assert.equal(clampSettings({ cyclesBeforeLong: 99 }).cyclesBeforeLong, 8);
  });

  it("maps a phase to milliseconds", () => {
    assert.equal(durationMs("focus", DEFAULT_SETTINGS), 1_500_000);
    assert.equal(durationMs("short", DEFAULT_SETTINGS), 300_000);
    assert.equal(durationMs("long", DEFAULT_SETTINGS), 900_000);
  });

  it("drops blank tasks and caps the list", () => {
    const tasks = sanitizeTasks([
      { id: "a", title: "  Outline  ", done: false, pomodoros: 2 },
      { title: "   " },
      null,
      { title: "Read", pomodoros: -3, done: true },
    ]);
    assert.equal(tasks.length, 2);
    assert.equal(tasks[0]?.title, "Outline");
    assert.equal(tasks[0]?.pomodoros, 2);
    assert.equal(tasks[1]?.done, true);
    assert.equal(tasks[1]?.pomodoros, 0);
  });
});
