export type Phase = "focus" | "short" | "long";

export type Settings = {
  focusMin: number;
  shortMin: number;
  longMin: number;
  cyclesBeforeLong: number;
  sound: boolean;
};

export type Task = {
  id: string;
  title: string;
  done: boolean;
  pomodoros: number;
};

export const DEFAULT_SETTINGS: Settings = {
  focusMin: 25,
  shortMin: 5,
  longMin: 15,
  cyclesBeforeLong: 4,
  sound: true,
};

export const PHASES: { id: Phase; short: string; label: string }[] = [
  { id: "focus", short: "Focus", label: "Focus" },
  { id: "short", short: "Break", label: "Short break" },
  { id: "long", short: "Long", label: "Long break" },
];

export function phaseLabel(phase: Phase): string {
  return PHASES.find((item) => item.id === phase)?.label ?? "Focus";
}

export function durationMs(phase: Phase, settings: Settings): number {
  const minutes =
    phase === "focus" ? settings.focusMin : phase === "short" ? settings.shortMin : settings.longMin;
  return minutes * 60_000;
}

export function formatClock(ms: number): string {
  const total = Math.min(99 * 60 + 59, Math.max(0, Math.ceil(ms / 1000)));
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}

export function statusLine(runState: "idle" | "running" | "paused", lastEvent: Phase | null): string {
  if (runState === "running") return "Running";
  if (runState === "paused") return "Paused";
  if (lastEvent === "focus") return "Focus complete";
  if (lastEvent === "short") return "Break complete";
  if (lastEvent === "long") return "Long break complete";
  return "Ready";
}

function clampInt(value: unknown, min: number, max: number, fallback: number): number {
  const numeric = typeof value === "number" ? value : Number.NaN;
  if (!Number.isFinite(numeric)) return fallback;
  return Math.min(max, Math.max(min, Math.round(numeric)));
}

export function clampSettings(input: Partial<Settings> | null | undefined): Settings {
  const src = input ?? {};
  return {
    focusMin: clampInt(src.focusMin, 1, 90, DEFAULT_SETTINGS.focusMin),
    shortMin: clampInt(src.shortMin, 1, 45, DEFAULT_SETTINGS.shortMin),
    longMin: clampInt(src.longMin, 1, 60, DEFAULT_SETTINGS.longMin),
    cyclesBeforeLong: clampInt(src.cyclesBeforeLong, 2, 8, DEFAULT_SETTINGS.cyclesBeforeLong),
    sound: typeof src.sound === "boolean" ? src.sound : DEFAULT_SETTINGS.sound,
  };
}

export function completePhase(input: {
  phase: Phase;
  cycleCount: number;
  completedToday: number;
  cyclesBeforeLong: number;
}): { phase: Phase; cycleCount: number; completedToday: number; countedFocus: boolean } {
  if (input.phase === "focus") {
    const completedToday = input.completedToday + 1;
    const cycleCount = input.cycleCount + 1;
    if (cycleCount >= input.cyclesBeforeLong) {
      return {
        phase: "long",
        cycleCount: input.cyclesBeforeLong,
        completedToday,
        countedFocus: true,
      };
    }
    return { phase: "short", cycleCount, completedToday, countedFocus: true };
  }
  if (input.phase === "long") {
    return {
      phase: "focus",
      cycleCount: 0,
      completedToday: input.completedToday,
      countedFocus: false,
    };
  }
  return {
    phase: "focus",
    cycleCount: input.cycleCount,
    completedToday: input.completedToday,
    countedFocus: false,
  };
}

export function sanitizeTasks(input: unknown): Task[] {
  if (!Array.isArray(input)) return [];
  const tasks: Task[] = [];
  for (const item of input) {
    if (!item || typeof item !== "object") continue;
    const record = item as Record<string, unknown>;
    const title = typeof record.title === "string" ? record.title.trim().slice(0, 120) : "";
    if (!title) continue;
    const id = typeof record.id === "string" && record.id ? record.id : crypto.randomUUID();
    const pomodoros =
      typeof record.pomodoros === "number" && Number.isFinite(record.pomodoros)
        ? Math.max(0, Math.round(record.pomodoros))
        : 0;
    tasks.push({ id, title, done: record.done === true, pomodoros });
    if (tasks.length >= 40) break;
  }
  return tasks;
}

export function todayKey(date = new Date()): string {
  return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
}
