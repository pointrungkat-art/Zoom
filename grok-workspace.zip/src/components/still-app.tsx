import { Volume2, VolumeX } from "lucide-react";
import { useEffect, useState } from "react";
import { SessionPanel } from "@/components/session-panel";
import { TaskList } from "@/components/task-list";
import { TimerPanel } from "@/components/timer-panel";
import { installAudioUnlock, playChime, unlockAudio } from "@/lib/chime";
import { usePomodoro } from "@/lib/pomodoro-store";
import { cn } from "@/lib/utils";

function useDateLabel() {
  const [label, setLabel] = useState("Focus timer");
  useEffect(() => {
    const formatted = new Intl.DateTimeFormat(undefined, {
      weekday: "long",
      month: "short",
      day: "numeric",
    }).format(new Date());
    setLabel(`Focus timer · ${formatted}`);
  }, []);
  return label;
}

function useHydratedPomodoro() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const unsub = usePomodoro.persist.onFinishHydration(() => setReady(true));
    void usePomodoro.persist.rehydrate();
    if (usePomodoro.persist.hasHydrated()) setReady(true);
    return unsub;
  }, []);
  return ready;
}

export function StillApp() {
  const ready = useHydratedPomodoro();
  const dateLabel = useDateLabel();
  const sound = usePomodoro((state) => state.settings.sound);
  const setSound = usePomodoro((state) => state.setSound);
  const tick = usePomodoro((state) => state.tick);
  const runState = usePomodoro((state) => state.runState);

  useEffect(() => {
    installAudioUnlock();
  }, []);

  useEffect(() => {
    if (!ready || runState !== "running") return;
    const id = window.setInterval(() => tick(Date.now()), 200);
    tick(Date.now());
    const onVisible = () => tick(Date.now());
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [ready, runState, tick]);

  useEffect(() => {
    if (!ready) return;
    return usePomodoro.subscribe((state, previous) => {
      if (state.completion !== previous.completion && state.settings.sound) playChime();
    });
  }, [ready]);

  return (
    <main className="app-shell mx-auto flex min-h-dvh w-full max-w-5xl flex-col">
      <header className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-xl font-semibold tracking-tight text-foreground">Still</h1>
          <p className="text-sm text-muted">{dateLabel}</p>
        </div>
        <button
          type="button"
          aria-pressed={sound}
          aria-label={sound ? "Chime on" : "Chime off"}
          className={cn(
            "pressable inline-flex h-11 shrink-0 items-center gap-2 rounded-sm px-3 text-sm font-medium",
            sound ? "bg-accent text-accent-foreground" : "text-muted hover:bg-subtle",
          )}
          onClick={() => {
            unlockAudio();
            setSound(!sound);
          }}
        >
          {sound ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
          Chime
        </button>
      </header>

      <div className="mx-auto mt-6 grid w-full max-w-3xl items-start gap-6 md:mt-12 md:grid-cols-[minmax(0,20rem)_minmax(0,22rem)] md:justify-center md:gap-16">
        <TimerPanel />
        <div className="flex flex-col gap-4">
          <SessionPanel />
          <TaskList />
        </div>
      </div>
    </main>
  );
}
