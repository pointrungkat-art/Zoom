import { Pause, Play, RotateCcw } from "lucide-react";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ProgressRing } from "@/components/progress-ring";
import { unlockAudio } from "@/lib/chime";
import { PHASES, formatClock, phaseLabel, statusLine } from "@/lib/pomodoro-logic";
import { usePomodoro } from "@/lib/pomodoro-store";
import { cn } from "@/lib/utils";

export function TimerPanel() {
  const phase = usePomodoro((state) => state.phase);
  const runState = usePomodoro((state) => state.runState);
  const remainingMs = usePomodoro((state) => state.remainingMs);
  const durationMs = usePomodoro((state) => state.durationMs);
  const lastEvent = usePomodoro((state) => state.lastEvent);
  const tasks = usePomodoro((state) => state.tasks);
  const activeTaskId = usePomodoro((state) => state.activeTaskId);
  const toggle = usePomodoro((state) => state.toggle);
  const reset = usePomodoro((state) => state.reset);
  const finishInterval = usePomodoro((state) => state.finishInterval);
  const selectPhase = usePomodoro((state) => state.selectPhase);

  const clock = formatClock(remainingMs);
  const label = phaseLabel(phase);
  const status = statusLine(runState, lastEvent);
  const activeTask = tasks.find((task) => task.id === activeTaskId) ?? null;
  const remaining = durationMs > 0 ? Math.min(1, Math.max(0, remainingMs / durationMs)) : 0;
  const phaseIndex = Math.max(0, PHASES.findIndex((item) => item.id === phase));

  useEffect(() => {
    if (runState === "running") document.title = `${clock} · ${label} — Still`;
    else if (runState === "paused") document.title = `Paused · ${clock} — Still`;
    else document.title = "Still";
    return () => {
      document.title = "Still";
    };
  }, [clock, label, runState]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.code !== "Space") return;
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.closest("input, textarea, button, a, [role='tab']")) return;
      event.preventDefault();
      unlockAudio();
      toggle();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle]);

  return (
    <section className="mx-auto w-full max-w-80" aria-label="Timer">
      <div
        role="timer"
        aria-label={`${clock}, ${label}, ${status}${activeTask ? `, ${activeTask.title}` : ""}`}
      >
        <ProgressRing remaining={remaining} paused={runState === "paused"}>
          <div className="flex flex-col items-center text-center">
            <p className="text-sm font-medium text-muted">{label}</p>
            <p className="mt-1 font-display text-timer text-foreground tabular-nums">{clock}</p>
            <p
              key={status}
              className={cn(
                "status-in mt-2 inline-flex items-center text-sm",
                runState === "running" ? "text-accent" : "text-muted",
              )}
            >
              {runState === "running" && (
                <span className="mr-2 inline-block size-1.5 rounded-full bg-accent" aria-hidden />
              )}
              {status}
            </p>
          </div>
        </ProgressRing>
      </div>

      {activeTask && (
        <p className="mt-4 truncate text-center text-sm text-foreground" title={activeTask.title}>
          {activeTask.title}
        </p>
      )}

      <div
        className="relative mt-6 grid grid-cols-3 rounded-md bg-subtle p-1"
        role="tablist"
        aria-label="Interval"
      >
        <span
          aria-hidden
          className="phase-indicator absolute top-1 bottom-1 left-1 rounded-sm bg-elevated shadow-panel"
          style={{
            width: "calc((100% - 0.5rem) / 3)",
            transform: `translateX(${phaseIndex * 100}%)`,
          }}
        />
        {PHASES.map((item) => {
          const selected = item.id === phase;
          return (
            <button
              key={item.id}
              type="button"
              role="tab"
              aria-selected={selected}
              aria-label={item.label}
              disabled={runState === "running" && !selected}
              className={cn(
                "pressable relative z-10 h-11 rounded-sm text-sm font-medium",
                selected ? "text-foreground" : "text-muted",
              )}
              onClick={() => selectPhase(item.id)}
            >
              {item.short}
            </button>
          );
        })}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <Button
          size="lg"
          onClick={() => {
            unlockAudio();
            toggle();
          }}
        >
          {runState === "running" ? <Pause className="size-4" /> : <Play className="size-4" />}
          {runState === "running" ? "Pause" : runState === "paused" ? "Resume" : "Start"}
        </Button>
        <Button size="lg" variant="secondary" onClick={reset}>
          <RotateCcw className="size-4" />
          Reset
        </Button>
      </div>

      {runState !== "idle" && (
        <button
          type="button"
          className="pressable mx-auto mt-1 flex h-11 items-center justify-center px-3 text-sm text-muted hover:text-foreground"
          onClick={() => {
            unlockAudio();
            finishInterval();
          }}
        >
          Finish early
        </button>
      )}

      <p className="mt-2 hidden text-center text-sm text-faint md:block">Space starts and pauses</p>
    </section>
  );
}
