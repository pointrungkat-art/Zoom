import { Minus, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { usePomodoro } from "@/lib/pomodoro-store";
import { cn } from "@/lib/utils";

const PRESETS = [
  { focus: 25, short: 5, label: "25 / 5" },
  { focus: 50, short: 10, label: "50 / 10" },
  { focus: 15, short: 3, label: "15 / 3" },
] as const;

function Stepper({
  label,
  value,
  min,
  max,
  unit,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  unit: string;
  onChange: (value: number) => void;
}) {
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
      <span className="text-sm font-medium leading-snug text-foreground">{label}</span>
      <div className="flex items-center gap-1">
        <Button
          variant="secondary"
          size="icon"
          aria-label={`Decrease ${label}`}
          disabled={value <= min}
          onClick={() => onChange(value - 1)}
        >
          <Minus className="size-4" />
        </Button>
        <span className="w-20 text-center text-sm whitespace-nowrap text-foreground tabular-nums">
          {value}
          {unit ? <span className="text-muted"> {unit}</span> : null}
        </span>
        <Button
          variant="secondary"
          size="icon"
          aria-label={`Increase ${label}`}
          disabled={value >= max}
          onClick={() => onChange(value + 1)}
        >
          <Plus className="size-4" />
        </Button>
      </div>
    </div>
  );
}

export function SessionPanel() {
  const completedToday = usePomodoro((state) => state.completedToday);
  const cycleCount = usePomodoro((state) => state.cycleCount);
  const settings = usePomodoro((state) => state.settings);
  const runState = usePomodoro((state) => state.runState);
  const setFocusMin = usePomodoro((state) => state.setFocusMin);
  const setShortMin = usePomodoro((state) => state.setShortMin);
  const setLongMin = usePomodoro((state) => state.setLongMin);
  const setCycles = usePomodoro((state) => state.setCycles);
  const applyPreset = usePomodoro((state) => state.applyPreset);
  const resetCounts = usePomodoro((state) => state.resetCounts);

  const caption =
    completedToday === 1 ? "1 focus session today" : `${completedToday} focus sessions today`;

  return (
    <section className="rounded-xl border border-border bg-elevated p-4 shadow-panel" aria-label="Session">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="font-display text-4xl leading-none text-foreground tabular-nums">{completedToday}</p>
          <p className="mt-2 text-sm text-muted">{caption}</p>
        </div>
        <div className="pt-1 text-right">
          <div
            className="flex justify-end gap-1.5"
            role="img"
            aria-label={`${cycleCount} of ${settings.cyclesBeforeLong} this cycle`}
          >
            {Array.from({ length: settings.cyclesBeforeLong }, (_, index) => (
              <span
                key={index}
                className={cn(
                  "size-2 rounded-full",
                  index < cycleCount ? "bg-accent" : "bg-subtle",
                )}
              />
            ))}
          </div>
          <p className="mt-2 text-sm text-muted">
            {cycleCount} of {settings.cyclesBeforeLong} this cycle
          </p>
        </div>
      </div>

      {(completedToday > 0 || cycleCount > 0) && (
        <button
          type="button"
          className="pressable mt-1 h-11 text-sm text-muted hover:text-foreground"
          onClick={resetCounts}
        >
          Reset count
        </button>
      )}

      <div className="mt-4 space-y-2 border-t border-border pt-4">
        <Stepper label="Work" value={settings.focusMin} min={1} max={90} unit="min" onChange={setFocusMin} />
        <Stepper
          label="Break"
          value={settings.shortMin}
          min={1}
          max={45}
          unit="min"
          onChange={setShortMin}
        />
        <Stepper
          label="Long break"
          value={settings.longMin}
          min={1}
          max={60}
          unit="min"
          onChange={setLongMin}
        />
        <Stepper
          label="Until long break"
          value={settings.cyclesBeforeLong}
          min={2}
          max={8}
          unit=""
          onChange={setCycles}
        />
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2">
        {PRESETS.map((preset) => {
          const active = settings.focusMin === preset.focus && settings.shortMin === preset.short;
          return (
            <button
              key={preset.label}
              type="button"
              aria-pressed={active}
              className={cn(
                "pressable h-11 rounded-sm border text-sm tabular-nums",
                active
                  ? "border-accent bg-accent text-accent-foreground"
                  : "border-border text-muted hover:text-foreground",
              )}
              onClick={() => applyPreset(preset.focus, preset.short)}
            >
              {preset.label}
            </button>
          );
        })}
      </div>

      {runState === "running" && (
        <p className="mt-3 text-sm text-muted">Length changes apply to the next interval.</p>
      )}
    </section>
  );
}
