import { Check, Trash2 } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { usePomodoro } from "@/lib/pomodoro-store";
import { cn } from "@/lib/utils";

export function TaskList() {
  const tasks = usePomodoro((state) => state.tasks);
  const activeTaskId = usePomodoro((state) => state.activeTaskId);
  const addTask = usePomodoro((state) => state.addTask);
  const toggleTask = usePomodoro((state) => state.toggleTask);
  const removeTask = usePomodoro((state) => state.removeTask);
  const setActiveTask = usePomodoro((state) => state.setActiveTask);
  const clearFinished = usePomodoro((state) => state.clearFinished);
  const [draft, setDraft] = useState("");
  const hasFinished = tasks.some((task) => task.done);
  const atLimit = tasks.length >= 40;

  return (
    <section className="rounded-xl border border-border bg-elevated p-4 shadow-panel" aria-labelledby="sitting-heading">
      <div className="flex items-baseline justify-between gap-3">
        <h2 id="sitting-heading" className="text-base font-medium text-foreground">
          This sitting
        </h2>
        {hasFinished && (
          <button
            type="button"
            className="pressable h-11 text-sm text-muted hover:text-foreground"
            onClick={clearFinished}
          >
            Clear finished
          </button>
        )}
      </div>
      <p className="text-sm text-muted">Tasks stay on this device. Tap one to make it current.</p>

      <form
        className="mt-4 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          addTask(draft);
          setDraft("");
        }}
      >
        <label className="sr-only" htmlFor="task-title">
          Task
        </label>
        <Input
          id="task-title"
          value={draft}
          maxLength={120}
          placeholder="What are you working on?"
          autoComplete="off"
          onChange={(event) => setDraft(event.target.value)}
        />
        <Button type="submit" variant="secondary" className="shrink-0" disabled={!draft.trim() || atLimit}>
          Add
        </Button>
      </form>

      {tasks.length === 0 ? (
        <p className="mt-4 text-sm text-muted">Nothing queued yet.</p>
      ) : (
        <ul className="mt-2">
          {tasks.map((task) => {
            const active = task.id === activeTaskId;
            return (
              <li key={task.id} className="border-b border-border last:border-b-0">
                <div className={cn("flex items-center gap-1 rounded-sm", active && "bg-subtle")}>
                  <button
                    type="button"
                    className="pressable flex size-11 shrink-0 items-center justify-center text-muted"
                    aria-pressed={task.done}
                    aria-label={task.done ? `Mark ${task.title} open` : `Mark ${task.title} done`}
                    onClick={() => toggleTask(task.id)}
                  >
                    <span
                      className={cn(
                        "flex size-4 items-center justify-center rounded-full border",
                        task.done ? "border-accent bg-accent text-accent-foreground" : "border-border",
                      )}
                    >
                      {task.done && <Check className="size-3" strokeWidth={2.5} />}
                    </span>
                  </button>
                  <button
                    type="button"
                    className="min-w-0 flex-1 py-2 text-left"
                    aria-pressed={active}
                    onClick={() => setActiveTask(task.id)}
                  >
                    {active && <span className="block text-xs font-medium text-accent">Now</span>}
                    <span
                      className={cn(
                        "block truncate text-sm",
                        task.done ? "text-muted line-through" : "text-foreground",
                      )}
                      title={task.title}
                    >
                      {task.title}
                    </span>
                  </button>
                  {task.pomodoros > 0 && (
                    <span className="shrink-0 text-sm text-faint tabular-nums" title="Focus intervals">
                      {task.pomodoros}
                    </span>
                  )}
                  <button
                    type="button"
                    className="pressable flex size-11 shrink-0 items-center justify-center text-muted hover:text-foreground"
                    aria-label={`Remove ${task.title}`}
                    onClick={() => removeTask(task.id)}
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
