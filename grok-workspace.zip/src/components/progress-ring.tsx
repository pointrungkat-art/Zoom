import type { ReactNode } from "react";

type ProgressRingProps = {
  /** Fraction of the interval still remaining, from 0 to 1. */
  remaining: number;
  paused?: boolean;
  children: ReactNode;
};

export function ProgressRing({ remaining, paused = false, children }: ProgressRingProps) {
  const size = 100;
  const stroke = 3.25;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const fraction = Math.min(1, Math.max(0, remaining));
  const offset = circumference * (1 - fraction);

  return (
    <div className="relative aspect-square w-full">
      <svg viewBox={`0 0 ${size} ${size}`} className="absolute inset-0 h-full w-full text-accent" aria-hidden>
        <circle
          cx={50}
          cy={50}
          r={radius}
          fill="none"
          className="stroke-border"
          strokeWidth={stroke}
        />
        <circle
          cx={50}
          cy={50}
          r={radius}
          fill="none"
          className="progress-arc stroke-accent"
          strokeWidth={stroke}
          strokeLinecap="round"
          opacity={paused ? 0.38 : 1}
          transform="rotate(-90 50 50)"
          style={{ strokeDasharray: circumference, strokeDashoffset: offset }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center px-12">{children}</div>
    </div>
  );
}
