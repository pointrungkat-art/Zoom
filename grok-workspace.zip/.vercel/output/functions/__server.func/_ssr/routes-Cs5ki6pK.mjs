import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, c as Pause, i as Trash2, l as Minus, n as Volume2, o as Plus, s as Play, t as VolumeX, u as Check } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cs5ki6pK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("pressable inline-flex items-center justify-center gap-2 rounded-sm font-medium whitespace-nowrap select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-40", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-foreground hover:opacity-90",
			secondary: "border border-border bg-elevated text-foreground hover:bg-subtle",
			ghost: "text-muted hover:bg-subtle hover:text-foreground"
		},
		size: {
			md: "h-11 px-4 text-sm",
			lg: "h-12 px-5 text-base",
			icon: "size-11 text-sm"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, type = "button", ...props }) {
	if (asChild) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var DEFAULT_SETTINGS = {
	focusMin: 25,
	shortMin: 5,
	longMin: 15,
	cyclesBeforeLong: 4,
	sound: true
};
var PHASES = [
	{
		id: "focus",
		short: "Focus",
		label: "Focus"
	},
	{
		id: "short",
		short: "Break",
		label: "Short break"
	},
	{
		id: "long",
		short: "Long",
		label: "Long break"
	}
];
function phaseLabel(phase) {
	return PHASES.find((item) => item.id === phase)?.label ?? "Focus";
}
function durationMs(phase, settings) {
	return (phase === "focus" ? settings.focusMin : phase === "short" ? settings.shortMin : settings.longMin) * 6e4;
}
function formatClock(ms) {
	const total = Math.min(5999, Math.max(0, Math.ceil(ms / 1e3)));
	const minutes = Math.floor(total / 60);
	const seconds = total % 60;
	return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}
function statusLine(runState, lastEvent) {
	if (runState === "running") return "Running";
	if (runState === "paused") return "Paused";
	if (lastEvent === "focus") return "Focus complete";
	if (lastEvent === "short") return "Break complete";
	if (lastEvent === "long") return "Long break complete";
	return "Ready";
}
function clampInt(value, min, max, fallback) {
	const numeric = typeof value === "number" ? value : NaN;
	if (!Number.isFinite(numeric)) return fallback;
	return Math.min(max, Math.max(min, Math.round(numeric)));
}
function clampSettings(input) {
	const src = input ?? {};
	return {
		focusMin: clampInt(src.focusMin, 1, 90, DEFAULT_SETTINGS.focusMin),
		shortMin: clampInt(src.shortMin, 1, 45, DEFAULT_SETTINGS.shortMin),
		longMin: clampInt(src.longMin, 1, 60, DEFAULT_SETTINGS.longMin),
		cyclesBeforeLong: clampInt(src.cyclesBeforeLong, 2, 8, DEFAULT_SETTINGS.cyclesBeforeLong),
		sound: typeof src.sound === "boolean" ? src.sound : DEFAULT_SETTINGS.sound
	};
}
function completePhase(input) {
	if (input.phase === "focus") {
		const completedToday = input.completedToday + 1;
		const cycleCount = input.cycleCount + 1;
		if (cycleCount >= input.cyclesBeforeLong) return {
			phase: "long",
			cycleCount: input.cyclesBeforeLong,
			completedToday,
			countedFocus: true
		};
		return {
			phase: "short",
			cycleCount,
			completedToday,
			countedFocus: true
		};
	}
	if (input.phase === "long") return {
		phase: "focus",
		cycleCount: 0,
		completedToday: input.completedToday,
		countedFocus: false
	};
	return {
		phase: "focus",
		cycleCount: input.cycleCount,
		completedToday: input.completedToday,
		countedFocus: false
	};
}
function sanitizeTasks(input) {
	if (!Array.isArray(input)) return [];
	const tasks = [];
	for (const item of input) {
		if (!item || typeof item !== "object") continue;
		const record = item;
		const title = typeof record.title === "string" ? record.title.trim().slice(0, 120) : "";
		if (!title) continue;
		const id = typeof record.id === "string" && record.id ? record.id : crypto.randomUUID();
		const pomodoros = typeof record.pomodoros === "number" && Number.isFinite(record.pomodoros) ? Math.max(0, Math.round(record.pomodoros)) : 0;
		tasks.push({
			id,
			title,
			done: record.done === true,
			pomodoros
		});
		if (tasks.length >= 40) break;
	}
	return tasks;
}
function todayKey(date = /* @__PURE__ */ new Date()) {
	return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
}
var INITIAL_DURATION = durationMs("focus", DEFAULT_SETTINGS);
function applySettings(state, settings) {
	const patch = { settings };
	if (state.cycleCount > settings.cyclesBeforeLong) patch.cycleCount = settings.cyclesBeforeLong;
	const nextDuration = durationMs(state.phase, settings);
	const previousDuration = durationMs(state.phase, state.settings);
	if (state.runState !== "running" && nextDuration !== previousDuration) {
		patch.durationMs = nextDuration;
		patch.remainingMs = nextDuration;
		patch.endsAt = null;
	}
	return patch;
}
function memoryStorage() {
	const bag = /* @__PURE__ */ new Map();
	return {
		get length() {
			return bag.size;
		},
		clear: () => bag.clear(),
		getItem: (key) => bag.get(key) ?? null,
		key: (index) => [...bag.keys()][index] ?? null,
		removeItem: (key) => {
			bag.delete(key);
		},
		setItem: (key, value) => {
			bag.set(key, value);
		}
	};
}
var usePomodoro = create()(persist((set, get) => ({
	phase: "focus",
	runState: "idle",
	endsAt: null,
	remainingMs: INITIAL_DURATION,
	durationMs: INITIAL_DURATION,
	completedToday: 0,
	cycleCount: 0,
	dayKey: "",
	tasks: [],
	activeTaskId: null,
	settings: DEFAULT_SETTINGS,
	completion: 0,
	lastEvent: null,
	toggle: () => {
		const state = get();
		if (state.runState === "running") {
			set({
				runState: "paused",
				endsAt: null,
				remainingMs: Math.max(0, (state.endsAt ?? Date.now()) - Date.now())
			});
			return;
		}
		if (state.remainingMs <= 0) {
			get().finishInterval();
			return;
		}
		set({
			runState: "running",
			endsAt: Date.now() + state.remainingMs,
			lastEvent: null
		});
	},
	reset: () => {
		const state = get();
		const duration = durationMs(state.phase, state.settings);
		set({
			runState: "idle",
			endsAt: null,
			remainingMs: duration,
			durationMs: duration,
			lastEvent: null
		});
	},
	finishInterval: () => {
		const state = get();
		if (state.runState === "idle") return;
		const result = completePhase({
			phase: state.phase,
			cycleCount: state.cycleCount,
			completedToday: state.completedToday,
			cyclesBeforeLong: state.settings.cyclesBeforeLong
		});
		const duration = durationMs(result.phase, state.settings);
		const tasks = result.countedFocus && state.activeTaskId ? state.tasks.map((task) => task.id === state.activeTaskId ? {
			...task,
			pomodoros: task.pomodoros + 1
		} : task) : state.tasks;
		set({
			phase: result.phase,
			cycleCount: result.cycleCount,
			completedToday: result.completedToday,
			tasks,
			runState: "idle",
			endsAt: null,
			remainingMs: duration,
			durationMs: duration,
			completion: state.completion + 1,
			lastEvent: state.phase
		});
	},
	selectPhase: (phase) => {
		const state = get();
		if (phase === state.phase || state.runState === "running") return;
		const duration = durationMs(phase, state.settings);
		set({
			phase,
			runState: "idle",
			endsAt: null,
			remainingMs: duration,
			durationMs: duration,
			lastEvent: null
		});
	},
	tick: (now) => {
		const state = get();
		const key = todayKey();
		if (state.dayKey !== key) set({
			dayKey: key,
			completedToday: 0,
			cycleCount: 0
		});
		const current = get();
		if (current.runState !== "running" || current.endsAt == null) return;
		const left = current.endsAt - now;
		if (left <= 0) {
			get().finishInterval();
			return;
		}
		if (Math.abs(left - current.remainingMs) > 40) set({ remainingMs: left });
	},
	setFocusMin: (value) => {
		const state = get();
		set(applySettings(state, clampSettings({
			...state.settings,
			focusMin: value
		})));
	},
	setShortMin: (value) => {
		const state = get();
		set(applySettings(state, clampSettings({
			...state.settings,
			shortMin: value
		})));
	},
	setLongMin: (value) => {
		const state = get();
		set(applySettings(state, clampSettings({
			...state.settings,
			longMin: value
		})));
	},
	setCycles: (value) => {
		const state = get();
		set(applySettings(state, clampSettings({
			...state.settings,
			cyclesBeforeLong: value
		})));
	},
	applyPreset: (focusMin, shortMin) => {
		const state = get();
		set(applySettings(state, clampSettings({
			...state.settings,
			focusMin,
			shortMin
		})));
	},
	setSound: (on) => {
		set({ settings: {
			...get().settings,
			sound: on
		} });
	},
	addTask: (title) => {
		const trimmed = title.trim().slice(0, 120);
		if (!trimmed) return;
		const state = get();
		if (state.tasks.length >= 40) return;
		const task = {
			id: crypto.randomUUID(),
			title: trimmed,
			done: false,
			pomodoros: 0
		};
		set({
			tasks: [task, ...state.tasks],
			activeTaskId: state.activeTaskId ?? task.id
		});
	},
	toggleTask: (id) => {
		const state = get();
		const tasks = state.tasks.map((task) => task.id === id ? {
			...task,
			done: !task.done
		} : task);
		const toggled = tasks.find((task) => task.id === id);
		let activeTaskId = state.activeTaskId;
		if (toggled?.done && activeTaskId === id) activeTaskId = tasks.find((task) => !task.done)?.id ?? null;
		else if (toggled && !toggled.done) activeTaskId = id;
		set({
			tasks,
			activeTaskId
		});
	},
	removeTask: (id) => {
		const state = get();
		const tasks = state.tasks.filter((task) => task.id !== id);
		set({
			tasks,
			activeTaskId: state.activeTaskId === id ? tasks.find((task) => !task.done)?.id ?? null : state.activeTaskId
		});
	},
	setActiveTask: (id) => {
		const state = get();
		if (!state.tasks.some((task) => task.id === id)) return;
		set({ activeTaskId: state.activeTaskId === id ? null : id });
	},
	clearFinished: () => {
		const state = get();
		const tasks = state.tasks.filter((task) => !task.done);
		set({
			tasks,
			activeTaskId: tasks.some((task) => task.id === state.activeTaskId) ? state.activeTaskId : null
		});
	},
	resetCounts: () => set({
		completedToday: 0,
		cycleCount: 0
	}),
	reconcile: () => {
		const state = get();
		const settings = clampSettings(state.settings);
		const key = todayKey();
		const rolled = state.dayKey !== key;
		const tasks = sanitizeTasks(state.tasks);
		const activeTaskId = tasks.some((task) => task.id === state.activeTaskId) ? state.activeTaskId : null;
		let phase = state.phase;
		let cycleCount = Math.min(rolled ? 0 : state.cycleCount, settings.cyclesBeforeLong);
		let completedToday = rolled ? 0 : state.completedToday;
		let runState = state.runState;
		let endsAt = state.endsAt;
		let remainingMs = state.remainingMs;
		let span = state.durationMs > 0 ? state.durationMs : durationMs(phase, settings);
		let lastEvent = state.lastEvent;
		if (runState === "running" && endsAt != null && endsAt <= Date.now()) {
			const finished = phase;
			const result = completePhase({
				phase,
				cycleCount,
				completedToday,
				cyclesBeforeLong: settings.cyclesBeforeLong
			});
			if (result.countedFocus && activeTaskId) {
				const index = tasks.findIndex((task) => task.id === activeTaskId);
				const current = index >= 0 ? tasks[index] : void 0;
				if (current) tasks[index] = {
					...current,
					pomodoros: current.pomodoros + 1
				};
			}
			phase = result.phase;
			cycleCount = result.cycleCount;
			completedToday = result.completedToday;
			span = durationMs(phase, settings);
			remainingMs = span;
			runState = "idle";
			endsAt = null;
			lastEvent = finished;
		} else if (runState === "running" && endsAt != null) remainingMs = Math.max(0, endsAt - Date.now());
		else remainingMs = Math.min(Math.max(0, remainingMs), span);
		set({
			settings,
			dayKey: key,
			tasks,
			activeTaskId,
			phase,
			cycleCount,
			completedToday,
			runState,
			endsAt,
			remainingMs,
			durationMs: span,
			lastEvent
		});
	}
}), {
	name: "still-pomodoro",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? memoryStorage() : window.localStorage),
	partialize: (state) => ({
		phase: state.phase,
		runState: state.runState,
		endsAt: state.endsAt,
		remainingMs: state.remainingMs,
		durationMs: state.durationMs,
		completedToday: state.completedToday,
		cycleCount: state.cycleCount,
		dayKey: state.dayKey,
		tasks: state.tasks,
		activeTaskId: state.activeTaskId,
		settings: state.settings
	}),
	onRehydrateStorage: () => (state) => {
		state?.reconcile();
	}
}));
var PRESETS = [
	{
		focus: 25,
		short: 5,
		label: "25 / 5"
	},
	{
		focus: 50,
		short: 10,
		label: "50 / 10"
	},
	{
		focus: 15,
		short: 3,
		label: "15 / 3"
	}
];
function Stepper({ label, value, min, max, unit, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium leading-snug text-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					size: "icon",
					"aria-label": `Decrease ${label}`,
					disabled: value <= min,
					onClick: () => onChange(value - 1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "w-20 text-center text-sm whitespace-nowrap text-foreground tabular-nums",
					children: [value, unit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [" ", unit]
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					size: "icon",
					"aria-label": `Increase ${label}`,
					disabled: value >= max,
					onClick: () => onChange(value + 1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
				})
			]
		})]
	});
}
function SessionPanel() {
	const completedToday = usePomodoro((state) => state.completedToday);
	const cycleCount = usePomodoro((state) => state.cycleCount);
	const settings = usePomodoro((state) => state.settings);
	const runState = usePomodoro((state) => state.runState);
	const setFocusMin = usePomodoro((state) => state.setFocusMin);
	const setShortMin = usePomodoro((state) => state.setShortMin);
	const setLongMin = usePomodoro((state) => state.setLongMin);
	const setCycles = usePomodoro((state) => state.setCycles);
	const applyPreset = usePomodoro((state) => state.applyPreset);
	const resetCounts = usePomodoro((state) => state.resetCounts);
	const caption = completedToday === 1 ? "1 focus session today" : `${completedToday} focus sessions today`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-elevated p-4 shadow-panel",
		"aria-label": "Session",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl leading-none text-foreground tabular-nums",
					children: completedToday
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: caption
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-1 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-end gap-1.5",
						role: "img",
						"aria-label": `${cycleCount} of ${settings.cyclesBeforeLong} this cycle`,
						children: Array.from({ length: settings.cyclesBeforeLong }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", index < cycleCount ? "bg-accent" : "bg-subtle") }, index))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							cycleCount,
							" of ",
							settings.cyclesBeforeLong,
							" this cycle"
						]
					})]
				})]
			}),
			(completedToday > 0 || cycleCount > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "pressable mt-1 h-11 text-sm text-muted hover:text-foreground",
				onClick: resetCounts,
				children: "Reset count"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-2 border-t border-border pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
						label: "Work",
						value: settings.focusMin,
						min: 1,
						max: 90,
						unit: "min",
						onChange: setFocusMin
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
						label: "Break",
						value: settings.shortMin,
						min: 1,
						max: 45,
						unit: "min",
						onChange: setShortMin
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
						label: "Long break",
						value: settings.longMin,
						min: 1,
						max: 60,
						unit: "min",
						onChange: setLongMin
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
						label: "Until long break",
						value: settings.cyclesBeforeLong,
						min: 2,
						max: 8,
						unit: "",
						onChange: setCycles
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-3 gap-2",
				children: PRESETS.map((preset) => {
					const active = settings.focusMin === preset.focus && settings.shortMin === preset.short;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": active,
						className: cn("pressable h-11 rounded-sm border text-sm tabular-nums", active ? "border-accent bg-accent text-accent-foreground" : "border-border text-muted hover:text-foreground"),
						onClick: () => applyPreset(preset.focus, preset.short),
						children: preset.label
					}, preset.label);
				})
			}),
			runState === "running" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Length changes apply to the next interval."
			})
		]
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-sm border border-border bg-elevated px-3 text-base text-foreground placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent", className),
		...props
	});
}
function TaskList() {
	const tasks = usePomodoro((state) => state.tasks);
	const activeTaskId = usePomodoro((state) => state.activeTaskId);
	const addTask = usePomodoro((state) => state.addTask);
	const toggleTask = usePomodoro((state) => state.toggleTask);
	const removeTask = usePomodoro((state) => state.removeTask);
	const setActiveTask = usePomodoro((state) => state.setActiveTask);
	const clearFinished = usePomodoro((state) => state.clearFinished);
	const [draft, setDraft] = (0, import_react.useState)("");
	const hasFinished = tasks.some((task) => task.done);
	const atLimit = tasks.length >= 40;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-elevated p-4 shadow-panel",
		"aria-labelledby": "sitting-heading",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "sitting-heading",
					className: "text-base font-medium text-foreground",
					children: "This sitting"
				}), hasFinished && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "pressable h-11 text-sm text-muted hover:text-foreground",
					onClick: clearFinished,
					children: "Clear finished"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Tasks stay on this device. Tap one to make it current."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					addTask(draft);
					setDraft("");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "task-title",
						children: "Task"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "task-title",
						value: draft,
						maxLength: 120,
						placeholder: "What are you working on?",
						autoComplete: "off",
						onChange: (event) => setDraft(event.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "secondary",
						className: "shrink-0",
						disabled: !draft.trim() || atLimit,
						children: "Add"
					})
				]
			}),
			tasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: "Nothing queued yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2",
				children: tasks.map((task) => {
					const active = task.id === activeTaskId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-b border-border last:border-b-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("flex items-center gap-1 rounded-sm", active && "bg-subtle"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "pressable flex size-11 shrink-0 items-center justify-center text-muted",
									"aria-pressed": task.done,
									"aria-label": task.done ? `Mark ${task.title} open` : `Mark ${task.title} done`,
									onClick: () => toggleTask(task.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("flex size-4 items-center justify-center rounded-full border", task.done ? "border-accent bg-accent text-accent-foreground" : "border-border"),
										children: task.done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "size-3",
											strokeWidth: 2.5
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "min-w-0 flex-1 py-2 text-left",
									"aria-pressed": active,
									onClick: () => setActiveTask(task.id),
									children: [active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs font-medium text-accent",
										children: "Now"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("block truncate text-sm", task.done ? "text-muted line-through" : "text-foreground"),
										title: task.title,
										children: task.title
									})]
								}),
								task.pomodoros > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 text-sm text-faint tabular-nums",
									title: "Focus intervals",
									children: task.pomodoros
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "pressable flex size-11 shrink-0 items-center justify-center text-muted hover:text-foreground",
									"aria-label": `Remove ${task.title}`,
									onClick: () => removeTask(task.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})
							]
						})
					}, task.id);
				})
			})
		]
	});
}
function ProgressRing({ remaining, paused = false, children }) {
	const size = 100;
	const stroke = 3.25;
	const radius = 96.75 / 2;
	const circumference = 2 * Math.PI * radius;
	const offset = circumference * (1 - Math.min(1, Math.max(0, remaining)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative aspect-square w-full",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: `0 0 ${size} ${size}`,
			className: "absolute inset-0 h-full w-full text-accent",
			"aria-hidden": true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: 50,
				cy: 50,
				r: radius,
				fill: "none",
				className: "stroke-border",
				strokeWidth: stroke
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: 50,
				cy: 50,
				r: radius,
				fill: "none",
				className: "progress-arc stroke-accent",
				strokeWidth: stroke,
				strokeLinecap: "round",
				opacity: paused ? .38 : 1,
				transform: "rotate(-90 50 50)",
				style: {
					strokeDasharray: circumference,
					strokeDashoffset: offset
				}
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 flex items-center justify-center px-12",
			children
		})]
	});
}
var audioCtx = null;
var unlockInstalled = false;
function context() {
	if (typeof window === "undefined") return null;
	const Ctx = window.AudioContext ?? window.webkitAudioContext;
	if (!Ctx) return null;
	if (!audioCtx) audioCtx = new Ctx();
	return audioCtx;
}
function unlockAudio() {
	try {
		const ctx = context();
		if (ctx && ctx.state === "suspended") ctx.resume();
	} catch {}
}
function installAudioUnlock() {
	if (unlockInstalled || typeof window === "undefined") return;
	unlockInstalled = true;
	const once = () => {
		unlockAudio();
		window.removeEventListener("pointerdown", once);
		window.removeEventListener("keydown", once);
	};
	window.addEventListener("pointerdown", once);
	window.addEventListener("keydown", once);
}
function playChime() {
	try {
		const ctx = context();
		if (!ctx) return;
		if (ctx.state === "suspended") ctx.resume();
		const now = ctx.currentTime;
		[392, 523.25].forEach((freq, index) => {
			const osc = ctx.createOscillator();
			const gain = ctx.createGain();
			osc.type = "sine";
			osc.frequency.value = freq;
			const start = now + index * .14;
			gain.gain.setValueAtTime(1e-4, start);
			gain.gain.exponentialRampToValueAtTime(.045, start + .04);
			gain.gain.exponentialRampToValueAtTime(1e-4, start + .95);
			osc.connect(gain);
			gain.connect(ctx.destination);
			osc.start(start);
			osc.stop(start + 1);
		});
	} catch {}
}
function TimerPanel() {
	const phase = usePomodoro((state) => state.phase);
	const runState = usePomodoro((state) => state.runState);
	const remainingMs = usePomodoro((state) => state.remainingMs);
	const durationMs = usePomodoro((state) => state.durationMs);
	const lastEvent = usePomodoro((state) => state.lastEvent);
	const tasks = usePomodoro((state) => state.tasks);
	const activeTaskId = usePomodoro((state) => state.activeTaskId);
	const toggle = usePomodoro((state) => state.toggle);
	const reset = usePomodoro((state) => state.reset);
	const finishInterval = usePomodoro((state) => state.finishInterval);
	const selectPhase = usePomodoro((state) => state.selectPhase);
	const clock = formatClock(remainingMs);
	const label = phaseLabel(phase);
	const status = statusLine(runState, lastEvent);
	const activeTask = tasks.find((task) => task.id === activeTaskId) ?? null;
	const remaining = durationMs > 0 ? Math.min(1, Math.max(0, remainingMs / durationMs)) : 0;
	const phaseIndex = Math.max(0, PHASES.findIndex((item) => item.id === phase));
	(0, import_react.useEffect)(() => {
		if (runState === "running") document.title = `${clock} · ${label} — Still`;
		else if (runState === "paused") document.title = `Paused · ${clock} — Still`;
		else document.title = "Still";
		return () => {
			document.title = "Still";
		};
	}, [
		clock,
		label,
		runState
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.code !== "Space") return;
			const target = event.target;
			if (!(target instanceof HTMLElement)) return;
			if (target.closest("input, textarea, button, a, [role='tab']")) return;
			event.preventDefault();
			unlockAudio();
			toggle();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [toggle]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto w-full max-w-80",
		"aria-label": "Timer",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "timer",
				"aria-label": `${clock}, ${label}, ${status}${activeTask ? `, ${activeTask.title}` : ""}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressRing, {
					remaining,
					paused: runState === "paused",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-muted",
								children: label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-timer text-foreground tabular-nums",
								children: clock
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: cn("status-in mt-2 inline-flex items-center text-sm", runState === "running" ? "text-accent" : "text-muted"),
								children: [runState === "running" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mr-2 inline-block size-1.5 rounded-full bg-accent",
									"aria-hidden": true
								}), status]
							}, status)
						]
					})
				})
			}),
			activeTask && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 truncate text-center text-sm text-foreground",
				title: activeTask.title,
				children: activeTask.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-6 grid grid-cols-3 rounded-md bg-subtle p-1",
				role: "tablist",
				"aria-label": "Interval",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					className: "phase-indicator absolute top-1 bottom-1 left-1 rounded-sm bg-elevated shadow-panel",
					style: {
						width: "calc((100% - 0.5rem) / 3)",
						transform: `translateX(${phaseIndex * 100}%)`
					}
				}), PHASES.map((item) => {
					const selected = item.id === phase;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": selected,
						"aria-label": item.label,
						disabled: runState === "running" && !selected,
						className: cn("pressable relative z-10 h-11 rounded-sm text-sm font-medium", selected ? "text-foreground" : "text-muted"),
						onClick: () => selectPhase(item.id),
						children: item.short
					}, item.id);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					onClick: () => {
						unlockAudio();
						toggle();
					},
					children: [runState === "running" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), runState === "running" ? "Pause" : runState === "paused" ? "Resume" : "Start"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					variant: "secondary",
					onClick: reset,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset"]
				})]
			}),
			runState !== "idle" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "pressable mx-auto mt-1 flex h-11 items-center justify-center px-3 text-sm text-muted hover:text-foreground",
				onClick: () => {
					unlockAudio();
					finishInterval();
				},
				children: "Finish early"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 hidden text-center text-sm text-faint md:block",
				children: "Space starts and pauses"
			})
		]
	});
}
function useDateLabel() {
	const [label, setLabel] = (0, import_react.useState)("Focus timer");
	(0, import_react.useEffect)(() => {
		const formatted = new Intl.DateTimeFormat(void 0, {
			weekday: "long",
			month: "short",
			day: "numeric"
		}).format(/* @__PURE__ */ new Date());
		setLabel(`Focus timer · ${formatted}`);
	}, []);
	return label;
}
function useHydratedPomodoro() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const unsub = usePomodoro.persist.onFinishHydration(() => setReady(true));
		usePomodoro.persist.rehydrate();
		if (usePomodoro.persist.hasHydrated()) setReady(true);
		return unsub;
	}, []);
	return ready;
}
function StillApp() {
	const ready = useHydratedPomodoro();
	const dateLabel = useDateLabel();
	const sound = usePomodoro((state) => state.settings.sound);
	const setSound = usePomodoro((state) => state.setSound);
	const tick = usePomodoro((state) => state.tick);
	const runState = usePomodoro((state) => state.runState);
	(0, import_react.useEffect)(() => {
		installAudioUnlock();
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready || runState !== "running") return;
		const id = window.setInterval(() => tick(Date.now()), 200);
		tick(Date.now());
		const onVisible = () => tick(Date.now());
		document.addEventListener("visibilitychange", onVisible);
		return () => {
			window.clearInterval(id);
			document.removeEventListener("visibilitychange", onVisible);
		};
	}, [
		ready,
		runState,
		tick
	]);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		return usePomodoro.subscribe((state, previous) => {
			if (state.completion !== previous.completion && state.settings.sound) playChime();
		});
	}, [ready]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "app-shell mx-auto flex min-h-dvh w-full max-w-5xl flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "Still"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: dateLabel
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": sound,
				"aria-label": sound ? "Chime on" : "Chime off",
				className: cn("pressable inline-flex h-11 shrink-0 items-center gap-2 rounded-sm px-3 text-sm font-medium", sound ? "bg-accent text-accent-foreground" : "text-muted hover:bg-subtle"),
				onClick: () => {
					unlockAudio();
					setSound(!sound);
				},
				children: [sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }), "Chime"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-6 grid w-full max-w-3xl items-start gap-6 md:mt-12 md:grid-cols-[minmax(0,20rem)_minmax(0,22rem)] md:justify-center md:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimerPanel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionPanel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskList, {})]
			})]
		})]
	});
}
var SplitComponent = StillApp;
//#endregion
export { SplitComponent as component };
