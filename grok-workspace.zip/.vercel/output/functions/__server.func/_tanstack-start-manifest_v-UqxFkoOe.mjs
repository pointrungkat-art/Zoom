//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-UqxFkoOe.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BUT2Z_uN.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BUT2Z_uN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C97r-g0N.js"]
	}
} });
//#endregion
export { tsrStartManifest };
